C1 Dummy Items project
Minecraft 1.20.1 / Forge 47.2.0 / Java 17

Adds exactly 20 simple items: c1 through c20. They are ordinary items with no skills, attacks, or movesets. They are listed in the Combat creative tab.

Texture: copied from the Hand Combat item texture in the user-provided effs-1.1.0.jar. This source project does not include the original mod's code, movesets, or other items.

BUILD (on a PC with Java 17 and Gradle installed):
1) Open this project folder in a terminal.
2) Run: gradle build
3) Output jar: build/libs/c1items-1.0.0.jar
4) Copy that jar into .minecraft/mods. Run Forge 1.20.1.

This is source only, not a precompiled JAR. It has not been compiled/tested here.
