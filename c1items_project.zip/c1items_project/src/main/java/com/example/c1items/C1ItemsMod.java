package com.example.c1items;

import net.minecraft.world.item.Item;
import net.minecraft.world.item.CreativeModeTabs;
import net.minecraftforge.event.BuildCreativeModeTabContentsEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;
import net.minecraftforge.eventbus.api.IEventBus;

@Mod(C1ItemsMod.MODID)
public class C1ItemsMod {
    public static final String MODID = "c1items";
    public static final DeferredRegister<Item> ITEMS = DeferredRegister.create(ForgeRegistries.ITEMS, MODID);
    public static final RegistryObject<Item>[] C_ITEMS = new RegistryObject[20];

    public C1ItemsMod() {
        IEventBus bus = FMLJavaModLoadingContext.get().getModEventBus();
        ITEMS.register(bus);
        for (int i = 1; i <= 20; i++) {
            final String id = "c" + i;
            C_ITEMS[i - 1] = ITEMS.register(id, () -> new Item(new Item.Properties()));
        }
        bus.addListener(this::addToCreative);
    }

    private void addToCreative(BuildCreativeModeTabContentsEvent event) {
        if (event.getTabKey() == CreativeModeTabs.COMBAT) {
            for (RegistryObject<Item> item : C_ITEMS) event.accept(item);
        }
    }
}
